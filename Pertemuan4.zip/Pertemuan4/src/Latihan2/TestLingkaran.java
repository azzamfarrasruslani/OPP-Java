
package Latihan2;



/**
 *
 * @author AZZAM FARRAS RUSLANI
 */
public class TestLingkaran {
    public static void main(String[] args) {
        Lingkaran ling1 = new Lingkaran(3, "biru");
        Lingkaran ling2 = new Lingkaran(6, "hitam");
        
        ling1.infoLingkaran();
        ling2.infoLingkaran();
    }
}
