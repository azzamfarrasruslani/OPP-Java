package Latihan1;

/**
 *
 * @author AZZAM FARRAS RUSLANI
 */
public class Test {
    public static void main(String[] args) {
        MyClass obj = new MyClass("azzam", "ti", 18);
        
        obj.info();
    }
  
}
